﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Agenda_Academica
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Cargar();
        }

        private void Cargar()
        {
            ClasesConexion conexion = new ClasesConexion();
            try
            {
                DgvClases.DataSource = conexion.ListarClases();

            }
            catch (Exception Ex)
            {

                MessageBox.Show(Ex.Message);
            }

        }

        private void BtnAgregar_Click(object sender, EventArgs e)
        {
            FrmAgregar ventana = new FrmAgregar();
            try
            {
                ventana.ShowDialog();
                Cargar();

            }
            catch (Exception Ex)
            {

                MessageBox.Show(Ex.Message);
            }
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            FrmEliminar ventana = new FrmEliminar();
            try
            {
                ventana.ShowDialog();
                Cargar();

            }
            catch (Exception Ex)
            {

                MessageBox.Show(Ex.Message);
            }
        }

        private void BtnModificar_Click(object sender, EventArgs e)
        {
            FrmModificar ventana = new FrmModificar();
            try
            {
                ventana.ShowDialog();
                Cargar();

            }
            catch (Exception Ex)
            {

                MessageBox.Show(Ex.Message);
            }
        }

        private void BtnTareas_Click(object sender, EventArgs e)
        {
            FrmTareas ventana = new FrmTareas();
            try
            {
                ventana.ShowDialog();
                Cargar();

            }
            catch (Exception Ex)
            {

                MessageBox.Show(Ex.Message);
            }
        }
    }
}
    
