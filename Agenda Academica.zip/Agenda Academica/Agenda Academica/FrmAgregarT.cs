﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Agenda_Academica
{
    public partial class FrmAgregarT : Form
    {
        public FrmAgregarT()
        {
            InitializeComponent();
        }

        private void BtnAceptar_Click(object sender, EventArgs e)
        {
            Tareas nuevo = new Tareas();
            TareasConexion conexion = new TareasConexion();
            try
            {
                nuevo.Nombre = TbNombre.Text;
                nuevo.Descripcion = TbDescripcion.Text;
                nuevo.Fecha = TbFecha.Text;
                nuevo.Horario = CbHorario.Text;

                conexion.Agregar(nuevo);

                Close();

            }
            catch (Exception Ex)
            {

                MessageBox.Show(Ex.Message);
            }
        }

        private void FrmAgregarT_Load(object sender, EventArgs e)
        {
            CbHorario.Items.Add("00:00");
            CbHorario.Items.Add("00:30");
            CbHorario.Items.Add("01:00");
            CbHorario.Items.Add("01:30");
            CbHorario.Items.Add("02:00");
            CbHorario.Items.Add("02:30");
            CbHorario.Items.Add("03:00");
            CbHorario.Items.Add("03:30");
            CbHorario.Items.Add("04:00");
            CbHorario.Items.Add("04:30");
            CbHorario.Items.Add("05:00");
            CbHorario.Items.Add("05:30");
            CbHorario.Items.Add("06:00");
            CbHorario.Items.Add("06:30");
            CbHorario.Items.Add("07:00");
            CbHorario.Items.Add("07:30");
            CbHorario.Items.Add("08:00");
            CbHorario.Items.Add("08:30");
            CbHorario.Items.Add("09:00");
            CbHorario.Items.Add("09:30");
            CbHorario.Items.Add("10:00");
            CbHorario.Items.Add("10:30");
            CbHorario.Items.Add("11:00");
            CbHorario.Items.Add("11:30");
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
