﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agenda_Academica
{
    class Clases
    {
        public string Nombre { get; set; }
        public string Inicio { get; set; }
        public string Fin { get; set; }
        public string Dias { get; set; }
        public string Establecimiento { get; set; }
    }
}
