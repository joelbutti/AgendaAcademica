﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agenda_Academica
{
    class ClasesConexion
    {
        public List<Clases> ListarClases()
        {
            List<Clases> Lista = new List<Clases>();
            SqlConnection conexion = new SqlConnection();
            SqlCommand comando = new SqlCommand();

            try
            {
                SqlDataReader lector;

                conexion.ConnectionString = "data source = DESKTOP-A3AHOCB; initial catalog=CLASES_DB; integrated security=sspi";
                comando.CommandType = System.Data.CommandType.Text;
                comando.CommandText = "select * from Clases";
                comando.Connection = conexion;
                conexion.Open();

                lector = comando.ExecuteReader();

                while (lector.Read())
                {
                    Clases aux = new Clases();
                    aux.Nombre = lector.GetString(1);
                    aux.Inicio = lector.GetString(2);
                    aux.Fin = lector.GetString(3);
                    aux.Dias = lector.GetString(4);
                    aux.Establecimiento = lector.GetString(5);

                    Lista.Add(aux);
                }

                conexion.Close();

                return Lista;

            }
            catch (Exception Ex)
            {

                throw Ex;
            }
        }

        internal void Modificar(Clases nuevo)
        {
            SqlConnection conexion = new SqlConnection("data source = DESKTOP-A3AHOCB; initial catalog=CLASES_DB; integrated security=sspi");
            SqlCommand comando = new SqlCommand();

            try
            {
                comando.Connection = conexion;
                comando.CommandType = System.Data.CommandType.Text;
                comando.Parameters.AddWithValue("@NombreCompleto", nuevo.Nombre);
                comando.Parameters.AddWithValue("@Inicio", nuevo.Inicio);
                comando.Parameters.AddWithValue("@Fin", nuevo.Fin);
                comando.Parameters.AddWithValue("@Dias", nuevo.Dias);
                comando.CommandText = "update dbo.Clases set Inicio= @Inicio, Fin= @Fin, Dias= @Dias where NombreCompleto = @NombreCompleto";

                conexion.Open();
                comando.ExecuteNonQuery();
                conexion.Close();

            }
            catch (Exception Ex)
            {

                throw Ex;
            }
        }

        internal void Eliminar(Clases nuevo)
        {
            SqlConnection conexion = new SqlConnection("data source = DESKTOP-A3AHOCB; initial catalog=CLASES_DB; integrated security=sspi");
            SqlCommand comando = new SqlCommand();

            try
            {
                comando.Connection = conexion;
                comando.CommandType = System.Data.CommandType.Text;
                comando.Parameters.AddWithValue("@NombreCompleto", nuevo.Nombre);
                comando.CommandText = "delete from dbo.Clases Where NombreCompleto = @NombreCompleto";

                conexion.Open();
                comando.ExecuteNonQuery();
                conexion.Close();

            }
            catch (Exception Ex)
            {

                throw Ex;
            }
        }

        internal void Agregar(Clases nuevo)
        {
            SqlConnection conexion = new SqlConnection("data source = DESKTOP-A3AHOCB; initial catalog=CLASES_DB; integrated security=sspi");
            SqlCommand comando = new SqlCommand();

            try
            {
                comando.Connection = conexion;
                comando.CommandType = System.Data.CommandType.Text;
                comando.Parameters.AddWithValue("@NombreCompleto", nuevo.Nombre);
                comando.Parameters.AddWithValue("@Inicio", nuevo.Inicio);
                comando.Parameters.AddWithValue("@Fin", nuevo.Fin);
                comando.Parameters.AddWithValue("@Dias", nuevo.Dias);
                comando.Parameters.AddWithValue("@Establecimiento", nuevo.Establecimiento);
                comando.CommandText = "insert into Clases (NombreCompleto, Inicio, Fin, Dias, Establecimiento) values (@NombreCompleto , @Inicio, @Fin , @Dias , @Establecimiento )";

                conexion.Open();
                comando.ExecuteNonQuery();
                conexion.Close();

            }
            catch (Exception Ex)
            {

                throw Ex;
            }
        }
    }
}
