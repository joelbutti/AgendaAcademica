﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agenda_Academica
{
    class TareasConexion
    {
        public List<Tareas> ListarTareas()
        {
            List<Tareas> Lista = new List<Tareas>();
            SqlConnection conexion = new SqlConnection();
            SqlCommand comando = new SqlCommand();

            try
            {
                SqlDataReader lector;

                conexion.ConnectionString = "data source = DESKTOP-A3AHOCB; initial catalog=TAREAS_DB; integrated security=sspi";
                comando.CommandType = System.Data.CommandType.Text;
                comando.CommandText = "select * from Tareas";
                comando.Connection = conexion;
                conexion.Open();

                lector = comando.ExecuteReader();

                while (lector.Read())
                {
                    Tareas aux = new Tareas();
                    aux.Nombre = lector.GetString(1);
                    aux.Descripcion = lector.GetString(2);
                    aux.Fecha = lector.GetString(3);
                    aux.Horario = lector.GetString(4);

                    Lista.Add(aux);
                }

                conexion.Close();

                return Lista;

            }
            catch (Exception Ex)
            {

                throw Ex;
            }
        }

        internal void Eliminar(Tareas nuevo)
        {
            SqlConnection conexion = new SqlConnection("data source = DESKTOP-A3AHOCB; initial catalog=TAREAS_DB; integrated security=sspi");
            SqlCommand comando = new SqlCommand();

            try
            {
                comando.Connection = conexion;
                comando.CommandType = System.Data.CommandType.Text;
                comando.Parameters.AddWithValue("@NombreCompleto", nuevo.Nombre);
                comando.CommandText = "delete from dbo.Tareas Where NombreCompleto = @NombreCompleto";

                conexion.Open();
                comando.ExecuteNonQuery();
                conexion.Close();

            }
            catch (Exception Ex)
            {

                throw Ex;
            }
        }

        internal void Modificar(Tareas nuevo)
        {
            SqlConnection conexion = new SqlConnection("data source = DESKTOP-A3AHOCB; initial catalog=TAREAS_DB; integrated security=sspi");
            SqlCommand comando = new SqlCommand();

            try
            {
                comando.Connection = conexion;
                comando.CommandType = System.Data.CommandType.Text;
                comando.Parameters.AddWithValue("@NombreCompleto", nuevo.Nombre);
                comando.Parameters.AddWithValue("@Descripcion", nuevo.Descripcion);
                comando.Parameters.AddWithValue("@Fecha", nuevo.Fecha);
                comando.Parameters.AddWithValue("@Horario", nuevo.Horario);
                comando.CommandText = "update dbo.Tareas set Descripcion= @Descripcion, Fecha= @Fecha, Horario= @Horario where NombreCompleto = @NombreCompleto";

                conexion.Open();
                comando.ExecuteNonQuery();
                conexion.Close();

            }
            catch (Exception Ex)
            {

                throw Ex;
            }
        }

        internal void Agregar(Tareas nuevo)
        {
            SqlConnection conexion = new SqlConnection("data source = DESKTOP-A3AHOCB; initial catalog=TAREAS_DB; integrated security=sspi");
            SqlCommand comando = new SqlCommand();

            try
            {
                comando.Connection = conexion;
                comando.CommandType = System.Data.CommandType.Text;
                comando.Parameters.AddWithValue("@NombreCompleto", nuevo.Nombre);
                comando.Parameters.AddWithValue("@Descripcion", nuevo.Descripcion);
                comando.Parameters.AddWithValue("@Fecha", nuevo.Fecha);
                comando.Parameters.AddWithValue("@Horario", nuevo.Horario);
                comando.CommandText = "insert into Tareas (NombreCompleto, Descripcion, Fecha, Horario) values (@NombreCompleto , @Descripcion, @Fecha , @Horario)";

                conexion.Open();
                comando.ExecuteNonQuery();
                conexion.Close();

            }
            catch (Exception Ex)
            {

                throw Ex;
            }
        }
    }
}
