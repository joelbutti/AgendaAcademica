﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Agenda_Academica
{
    public partial class FrmAgregar : Form
    {
        public FrmAgregar()
        {
            InitializeComponent();
        }

        private void FrmAgregar_Load(object sender, EventArgs e)
        {
            CbInicio.Items.Add("00:00");
            CbInicio.Items.Add("00:30");
            CbInicio.Items.Add("01:00");
            CbInicio.Items.Add("01:30");
            CbInicio.Items.Add("02:00");
            CbInicio.Items.Add("02:30");
            CbInicio.Items.Add("03:00");
            CbInicio.Items.Add("03:30");
            CbInicio.Items.Add("04:00");
            CbInicio.Items.Add("04:30");
            CbInicio.Items.Add("05:00");
            CbInicio.Items.Add("05:30");
            CbInicio.Items.Add("06:00");
            CbInicio.Items.Add("06:30");
            CbInicio.Items.Add("07:00");
            CbInicio.Items.Add("07:30");
            CbInicio.Items.Add("08:00");
            CbInicio.Items.Add("08:30");
            CbInicio.Items.Add("09:00");
            CbInicio.Items.Add("09:30");
            CbInicio.Items.Add("10:00");
            CbInicio.Items.Add("10:30");
            CbInicio.Items.Add("11:00");
            CbInicio.Items.Add("11:30");
            

            CbFin.Items.Add("00:00");
            CbFin.Items.Add("00:30");
            CbFin.Items.Add("01:00");
            CbFin.Items.Add("01:30");
            CbFin.Items.Add("02:00");
            CbFin.Items.Add("02:30");
            CbFin.Items.Add("03:00");
            CbFin.Items.Add("03:30");
            CbFin.Items.Add("04:00");
            CbFin.Items.Add("04:30");
            CbFin.Items.Add("05:00");
            CbFin.Items.Add("05:30");
            CbFin.Items.Add("06:00");
            CbFin.Items.Add("06:30");
            CbFin.Items.Add("07:00");
            CbFin.Items.Add("07:30");
            CbFin.Items.Add("08:00");
            CbFin.Items.Add("08:30");
            CbFin.Items.Add("09:00");
            CbFin.Items.Add("09:30");
            CbFin.Items.Add("10:00");
            CbFin.Items.Add("10:30");
            CbFin.Items.Add("11:00");
            CbFin.Items.Add("11:30");
        }

        private void BtnAceptar_Click(object sender, EventArgs e)
        {
            Clases nuevo = new Clases();
            ClasesConexion conexion = new ClasesConexion();
            try
            {
                nuevo.Nombre = TbNombre.Text;
                nuevo.Inicio = CbInicio.Text;
                nuevo.Fin = CbFin.Text;
                nuevo.Dias = TbDias.Text;
                nuevo.Establecimiento = TbEstablecimiento.Text;

                conexion.Agregar(nuevo);

                Close();

            }
            catch (Exception Ex)
            {

                MessageBox.Show(Ex.Message);
            }
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
