﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Agenda_Academica
{
    public partial class FrmTareas : Form
    {
        public FrmTareas()
        {
            InitializeComponent();
        }

        private void FrmTareas_Load(object sender, EventArgs e)
        {
            Cargar();
        }

        private void Cargar()
        {
            TareasConexion conexion = new TareasConexion();
            try
            {
                DgvTareas.DataSource = conexion.ListarTareas();

            }
            catch (Exception Ex)
            {

                MessageBox.Show(Ex.Message);
            }

        }

        private void BtnAgregar_Click(object sender, EventArgs e)
        {
            FrmAgregarT ventana = new FrmAgregarT();
            try
            {
                ventana.ShowDialog();
                Cargar();

            }
            catch (Exception Ex)
            {

                MessageBox.Show(Ex.Message);
            }
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            FrmEliminarT ventana = new FrmEliminarT();
            try
            {
                ventana.ShowDialog();
                Cargar();

            }
            catch (Exception Ex)
            {

                MessageBox.Show(Ex.Message);
            }
        }

        private void BtnModificar_Click(object sender, EventArgs e)
        {
            FrmModificarT ventana = new FrmModificarT();
            try
            {
                ventana.ShowDialog();
                Cargar();

            }
            catch (Exception Ex)
            {

                MessageBox.Show(Ex.Message);
            }
        }
    }
}
